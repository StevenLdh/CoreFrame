# Coldairarrow.Fx.Core.Easyui.GitHub
Web后台快速开发框架,.NETCore2.1版本

使用方式：https://github.com/Coldairarrow/Coldairarrow.Fx.Core.Easyui.GitHub/wiki
