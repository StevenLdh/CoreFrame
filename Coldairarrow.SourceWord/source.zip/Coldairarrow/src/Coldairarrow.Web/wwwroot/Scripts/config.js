﻿//前端配置信息
var config = {
    //应用Id
    appId: "AppTest",
    //应用密钥
    appSecret: "7c109ae2-cc14-4328-9cb9-3f8c0433cfb2",
    //百度地图使用的key
    BaiduMapKey: '6BRpIPAF8Z87yrIwoPiSK7kykvGtp2wg'
};