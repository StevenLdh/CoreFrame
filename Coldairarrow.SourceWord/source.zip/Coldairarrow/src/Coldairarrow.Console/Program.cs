﻿using System;

namespace Coldairarrow.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("完成");
            Console.ReadLine();
        }
    }
}
